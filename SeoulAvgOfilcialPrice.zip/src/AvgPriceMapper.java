import org.apache.hadoop.io.Text; // 문자열 형식 키
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException; // 예외처리
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;

public class AvgPriceMapper extends Mapper<LongWritable, Text, Text, LongWritable> {
	
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		DataParser parser = new DataParser(value);
		String si = parser.getSi();
		String dong = parser.getDong();
		long price = parser.getPrice();
		context.write(new Text(dong), new LongWritable(price));
		context.write(new Text(si), new LongWritable(price));
	}

}
