import org.apache.hadoop.io.Text;
import java.util.StringTokenizer;
public class DataParser {
	private String si;
	private String gu;
	private String dong;
	private long price;
	private int year;
	
	
	public DataParser(Text value) {
		String data = value.toString();
		StringTokenizer strs= new StringTokenizer(data,"\",");
		String[] tokens = new String[strs.countTokens()];
		for(int i = 0; i < tokens.length; i++) {
			tokens[i] = strs.nextToken();
		}

		this.si = tokens[0];
		this.gu = tokens[1];
		this.dong = tokens[2];
		this.price = Long.parseLong(tokens[4]);
	}


	public String getSi() {
		return si;
	}


	public void setSi(String si) {
		this.si = si;
	}


	public String getGu() {
		return gu;
	}


	public void setGu(String gu) {
		this.gu = gu;
	}


	public String getDong() {
		return dong;
	}


	public void setDong(String dong) {
		this.dong = dong;
	}


	public long getPrice() {
		return price;
	}


	public void setPrice(long price) {
		this.price = price;
	}

	public int getYear() {
		return year;
	}


	public void setYear(int year) {
		this.year = year;
	}
}
