import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class AvgPriceReducer extends Reducer<Text, LongWritable, Text, LongWritable>{

	@Override
	protected void reduce(Text Key, Iterable<LongWritable> values,
			Reducer<Text, LongWritable, Text, LongWritable>.Context context) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		long avg_price = 0;
		long sum_price = 0;
		int cnt = 0;
		for (LongWritable value : values) {
			sum_price += value.get();
			cnt ++;
		}
		avg_price = (long) (3.3 * sum_price / cnt);
		
		context.write(Key, new LongWritable(avg_price));
	}
	
}
