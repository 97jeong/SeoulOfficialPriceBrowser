package SeoulOfficialPriceBrower;

public class MainMenu implements Menu{
	
	private static final MainMenu myMenu = new MainMenu();
	public static boolean isOn;
	
	private MainMenu() {
		isOn = true;
	}
	
	public static MainMenu getInstance() {
		return myMenu;
	}
	
	@Override
	public void showMenu() {
		// TODO Auto-generated method stub
		System.out.println("1. 공시지가 조회 | 2. 평당가 조회 | 3. 상승률 조회 | 4. 프로그램 종료");
		System.out.print("선택> ");	
	}
		
	@Override
	public void selectOption() throws Exception {
		// TODO Auto-generated method stub
		String option = sc.nextLine();
		switch (option) {
			case "1":
				new OfficialPrice();
				break;
			case "2":
				new PricePerPyong();
				break;
			case "3":
				new PriceAscentRate();
				break;
			case "4":
				isOn = false;
				System.out.println("프로그램 종료");
				break;
			default:
				System.out.println("Input optionBoundary");
				showMenu();
				selectOption();
		}
	}
}
