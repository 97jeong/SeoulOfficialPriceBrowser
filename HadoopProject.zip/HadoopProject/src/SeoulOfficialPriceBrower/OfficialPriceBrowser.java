package SeoulOfficialPriceBrower;

public class OfficialPriceBrowser {
	
	public static void main(String[] args) throws Exception {
		Menu menu = MainMenu.getInstance();
		System.out.println("------------------------- 서울 공시지가 열람 시스템 -------------------------");
		
		while(MainMenu.isOn) {
			menu.showMenu();
			menu.selectOption();	
		}
	}
}
