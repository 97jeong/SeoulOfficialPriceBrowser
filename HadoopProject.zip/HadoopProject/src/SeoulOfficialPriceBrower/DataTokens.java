package SeoulOfficialPriceBrower;

public class DataTokens {
	private String key;
	private int price;
	private double rate;
	
	public DataTokens (String key, int price){
		this.key = key;
		this.price = price;
	}

	public String getTokens() {
		String tokens = key + "\t" + price;
		return tokens;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}
}
