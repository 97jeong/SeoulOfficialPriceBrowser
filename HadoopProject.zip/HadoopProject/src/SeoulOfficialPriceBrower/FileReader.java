package SeoulOfficialPriceBrower;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

public class FileReader {
	
	private String url;
	private ArrayList<DataTokens> listTokens = new ArrayList<>();
	private String data;
	
	public FileReader(String directory) throws Exception {
		url = "http://192.168.201.128:50070/webhdfs/v1/user/user/output/" + directory + "/part-r-00000?op=OPEN";
		readFile(url);
	}
	
	public void readFile(String url) throws Exception {
		InputStream in = null; 
		StringBuffer strbuf = new StringBuffer();
		
		try { 
			in = new URL(url).openStream();
			InputStreamReader isr = new InputStreamReader(in, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
			while((data = br.readLine()) != null) {
				strbuf.append(data + "원(m^2)\r\n");
				String[] token = data.split("\t");
				listTokens.add(new DataTokens(token[0], Integer.parseInt(token[1])));
			}
			this.data = strbuf.toString();
		}
		finally {
			in.close();
		}	
	}

	public ArrayList<DataTokens> getListTokens() {
		return listTokens;
	}

	public void setListTokens(ArrayList<DataTokens> listTokens) {
		this.listTokens = listTokens;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}
