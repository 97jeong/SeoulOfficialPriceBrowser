package SeoulOfficialPriceBrower;

import java.util.ArrayList;

public class PriceAscentRate implements Menu{

	private String pastDirectory;
	private String currDirectory;
	private String option;
	
	public PriceAscentRate() throws Exception {
		this.pastDirectory = null;
		this.currDirectory = null;
		this.option = null;
		
		showMenu();
		selectOption();
	}
	
	@Override
	public void showMenu() {
		// TODO Auto-generated method stub
		System.out.println("------------------------- 공시지가 상승률 조회 (10년간) -------------------------");
		System.out.println("1. 서울 평균 상승률 | 2. 법정동별 평균 상승률 | 3. 상승률 검색 | 4. 뒤로가기");
		System.out.print("선택> ");
	}


	@Override
	public void selectOption() throws Exception{
		// TODO Auto-generated method stub
		option = sc.nextLine();
		ArrayList<DataTokens> currList;
		ArrayList<DataTokens> pastList;
		switch (option) {
			case "1":
				currDirectory = "CurrAvgofSi";
				currList = new FileReader(currDirectory).getListTokens();
				pastDirectory = "PastAvgofSi";
				pastList = new FileReader(pastDirectory).getListTokens();
				showAscentRate(pastList, currList);
				break;
				
			case "2":
				currDirectory = "CurrAvgofDong";
				currList = new FileReader(currDirectory).getListTokens();
				pastDirectory = "PastAvgofDong";
				pastList = new FileReader(pastDirectory).getListTokens();
				showAscentRate(pastList, currList);
				break;
				
			case "3":
				currDirectory = "CurrAvgofDong";
				currList = new FileReader(currDirectory).getListTokens();
				pastDirectory = "PastAvgofDong";
				pastList = new FileReader(pastDirectory).getListTokens();
				DataTokens searchData = searchDong(pastList, currList);
				if(searchData != null) {
					System.out.printf("%s\t %.1f%% \n", searchData.getKey(), searchData.getRate());
				} else {
					System.out.println("데이터가 존재하지 않습니다.");
				}
				break;
				
			case "4":
				MainMenu.getInstance();
				break;
				
			default:
				System.out.println("Input optionBoundary");
				showMenu();
				selectOption();
			}
	}

	public void showAscentRate(ArrayList<DataTokens> pastList, ArrayList<DataTokens> currList) {
		double rate;
		for(int i = 0; i < pastList.size(); i++) {
			for(int j = 0; j < currList.size(); j++) {
				String pastKey = pastList.get(i).getKey();
				int pastPrice = pastList.get(i).getPrice();
				String currKey = currList.get(j).getKey();
				int currPrice = currList.get(j).getPrice();
				if(pastKey.equals(currKey)) {
					rate = ((currPrice - pastPrice) / (double) pastPrice) * 100;
					System.out.printf("%s\t %.1f%% \n", currKey, rate);
				}
			}
		}
	}
}
