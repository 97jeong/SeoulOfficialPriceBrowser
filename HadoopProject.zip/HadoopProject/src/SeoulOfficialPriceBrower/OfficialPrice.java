package SeoulOfficialPriceBrower;

public class OfficialPrice implements Menu{

	private String directory;
	private String option;
	
	public OfficialPrice() throws Exception {
		this.directory = null;
		this.option = null;
		
		showMenu();
		selectOption();
	}
	
	@Override
	public void showMenu() {
		// TODO Auto-generated method stub
		System.out.println("------------------------- 공시지가 조회 -------------------------");
		System.out.println("1. 서울 평균 공시지가 | 2. 법정동별 평균 공시지가 | 3. 공시지가 검색 | 4. 뒤로가기");
		System.out.print("선택> ");
	}


	@Override
	public void selectOption() throws Exception{
		// TODO Auto-generated method stub
		option = sc.nextLine();
		FileReader fileReader = null;
		switch (option) {
			case "1":
				directory = "CurrAvgofSi";
				fileReader = new FileReader(directory);
				System.out.println(fileReader.getData());
				break;
				
			case "2":
				directory = "CurrAvgofDong";
				fileReader = new FileReader(directory);
				System.out.println(fileReader.getData());
				break;
				
			case "3":
				directory = "CurrAvgofDong";
				fileReader = new FileReader(directory);
				DataTokens searchData = searchDong(fileReader.getListTokens());
				if(searchData != null) {
					System.out.println(searchData.getTokens() + "원(m^2)");	
				} else {
					System.out.println("데이터에 존재하지 않습니다.");
				}
				break;
				
			case "4":
				MainMenu.getInstance();
				break;
				
			default:
				System.out.println("Input optionBoundary");
				showMenu();
				selectOption();
			}
	}
}
