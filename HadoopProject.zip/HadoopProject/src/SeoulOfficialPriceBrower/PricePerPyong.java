package SeoulOfficialPriceBrower;

import java.util.ArrayList;

public class PricePerPyong implements Menu{

	private String directory;
	private String option;
	
	public PricePerPyong() throws Exception {
		this.directory = null;
		this.option = null;
		
		showMenu();
		selectOption();
	}
	
	@Override
	public void showMenu() {
		// TODO Auto-generated method stub
		System.out.println("------------------------- 평당가 조회 -------------------------");
		System.out.println("1. 서울 평균 평당가 | 2. 법정동별 평균 평당가 | 3. 평당가 검색 | 4. 뒤로가기");
		System.out.print("선택> ");
	}


	@Override
	public void selectOption() throws Exception{
		// TODO Auto-generated method stub
		option = sc.nextLine();
		FileReader fileReader = null;
		switch (option) {
			case "1":
				directory = "CurrAvgofSi";
				fileReader = new FileReader(directory);
				showPricePerPyong(fileReader.getListTokens());
				break;
				
			case "2":
				directory = "CurrAvgofDong";
				fileReader = new FileReader(directory);
				showPricePerPyong(fileReader.getListTokens());
				break;
				
			case "3":
				directory = "CurrAvgofDong";
				fileReader = new FileReader(directory);
				DataTokens searchData = searchDong(fileReader.getListTokens());
				if(searchData != null) {
					showPricePerPyong(searchData);
				} else {
					System.out.println("데이터에 존재하지 않습니다.");
				}
				break;
				
			case "4":
				MainMenu.getInstance();
				break;
				
			default:
				System.out.println("Input optionBoundary");
				showMenu();
				selectOption();
		}
	}
	
	public void showPricePerPyong(ArrayList<DataTokens> list) {
		for(int i = 0; i < list.size(); i++) {
			int pyongPrice = (int) (3.3 * list.get(i).getPrice());
			list.get(i).setPrice(pyongPrice);
			System.out.println(list.get(i).getTokens() + "원(평)");
		}
	}
	
	public void showPricePerPyong(DataTokens searchData) {
		int pyongPrice = (int) (3.3 * searchData.getPrice());
		searchData.setPrice(pyongPrice);
		System.out.println(searchData.getTokens() + "원(평)");
	}
}
