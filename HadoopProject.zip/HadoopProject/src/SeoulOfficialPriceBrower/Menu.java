package SeoulOfficialPriceBrower;

import java.util.ArrayList;
import java.util.Scanner;

public interface Menu {
	Scanner sc = new Scanner(System.in);
	
	void showMenu();
	void selectOption() throws Exception;
	
	default DataTokens searchDong(ArrayList<DataTokens> list) {
		System.out.print("검색 (ex. 역삼동) > ");
		String dong = sc.nextLine();
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getKey().equals(dong)) {
				return list.get(i);	
			}
		}
		return null;
	}
	
	default DataTokens searchDong(ArrayList<DataTokens> pastList, ArrayList<DataTokens> currList) {
		double rate;
		System.out.print("검색 (ex. 역삼동) > ");
		String dong = sc.nextLine();
		for(int i = 0; i < pastList.size(); i++) {
			for(int j = 0; j < currList.size(); j++) {
				String pastKey = pastList.get(i).getKey();
				int pastPrice = pastList.get(i).getPrice();
				String currKey = currList.get(j).getKey();
				int currPrice = currList.get(j).getPrice();
				if(dong.equals(pastKey) && dong.equals(currKey)) {
					rate = ((currPrice - pastPrice) / (double) pastPrice) * 100;
					currList.get(j).setRate(rate);
					return currList.get(j);
				}
			}
		}
		return null;
	}
}
